package com.example.activitylifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("apssdc","Activity created");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("apssdc","Activity started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("apssdc","Activity resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("apssdc","Activity paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("apssdc","Activity stopped");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("apssdc","Activity restarted");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("apssdc","Activity destroyed");
    }
}